﻿#Do poprawnego działania programu wymagana jest instalacja oprogramowania - Anaconda 3.6.5 
#zawiera ona oprogramowanie do obliczen statystycznych dla języka Python
import csv 
import sys

import numpy as np
import matplotlib.pyplot as plt
from itertools import cycle

from sklearn import svm
from sklearn.metrics import roc_curve, auc
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import label_binarize
from sklearn.multiclass import OneVsRestClassifier
from scipy import interp

# Import danych
file = open('input_popr.csv')
reader = csv.reader(file)
n_classes = int(file.readline())

y = []
X = []

for line in reader:
      
       y.append(int(line[0]))
       X.append(line[1:])


y = label_binarize(y, classes=list(range(0, n_classes))) # podzial na 1 vs reszta

random_state = np.random.RandomState(0)

n_samples = len(X) #ilosc obserwacji
n_features = len(X[0]) #ilosc danych obserwacji
X = np.c_[X, random_state.randn(n_samples, n_features)]

# Rozdzial na dane uczace i testujace

procent_danych_testowych = 0.25
procent_danych_uczacych = 1 - procent_danych_testowych 
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=procent_danych_testowych,
                                                    train_size = procent_danych_uczacych,random_state=1)


# klasyfikator sam sie uczy przewidywac prawdopodobienstwo
classifier = OneVsRestClassifier(svm.SVC(kernel='linear', probability=True,
                                 random_state=0))
y_score = classifier.fit(X_train, y_train).decision_function(X_test)

# Liczymy ROC i AUC

fpr = dict()
tpr = dict()
roc_auc = dict()

for i in range(n_classes):
    #rozpakowywujemy dane z y_test i y_score na fpr i tpr, placeholder umieszczamy bo roc_curvey zwraca 3 wartosci a 3 nie potrzebuje
    fpr[i], tpr[i], nic = roc_curve(y_test[:, i], y_score[:, i])
    roc_auc[i] = auc(fpr[i], tpr[i])

    #zbieramy wszystkie fpr do jednego zbioru
all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))


# Przygotowujemy liste wartosci posrednich tpr
pos_tpr = np.zeros_like(all_fpr)

for i in range(n_classes):
    pos_tpr += interp(all_fpr, fpr[i], tpr[i])

# Dzielimy tpr przez liczbe klas
pos_tpr /= n_classes

fpr["macro"] = all_fpr
tpr["macro"] = pos_tpr
roc_auc["macro"] = auc(fpr["macro"], tpr["macro"])

# Rysowanie
plt.figure()
line_width = 2

colors = cycle(['gold', 'red', 'teal','darkorange','chocolote','magenta','cyan','pink','green','maroon'])
for i, color in zip(range(n_classes), colors):
    plt.plot(fpr[i], tpr[i], color=color, lw=line_width,
             label='AUC dla klasy {0} (AUC = {1:0.2f})'
             ''.format(i, roc_auc[i]))

plt.plot([0, 1], [0, 1], 'k--', lw=1)
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.0])
plt.xlabel('100 - Czułość')
plt.ylabel('Czułość')
plt.title('Wykres ROC dla k-klas')
plt.legend(loc="lower right")
plt.show()
